package com.example.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    String ayuda, ayuda2, ayuda3;
    int ayudita, ayudita3, ayudita4 = 0;
    double  ayudita2, ayudita5;
    double help1, help2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1 = findViewById(R.id.uno);
        Button button2 = findViewById(R.id.dos);
        Button button3 = findViewById(R.id.tres);
        Button button4 = findViewById(R.id.cuatro);
        Button button5 = findViewById(R.id.cinco);
        Button button6 = findViewById(R.id.seis);
        Button button7 = findViewById(R.id.siete);
        Button button8 = findViewById(R.id.ocho);
        Button button9 = findViewById(R.id.nueve);
        Button button0 = findViewById(R.id.cero);
        Button buttonsuma = findViewById(R.id.suma);
        Button buttonresta = findViewById(R.id.resta);
        Button buttondiv = findViewById(R.id.division);
        Button buttonmulti = findViewById(R.id.multiplicacion);
        Button buttonsen = findViewById(R.id.sen);
        Button buttoncos = findViewById(R.id.cos);
        Button buttontan = findViewById(R.id.tan);
        Button buttonPot = findViewById(R.id.potencia);
        Button buttonRaiz = findViewById(R.id.raiz);
        Button buttonIgual = findViewById(R.id.igual);
        Button buttonClear = findViewById(R.id.clear);
        Button buttonBorrar = findViewById(R.id.borrar);
        Button buttonMenos = findViewById(R.id.menos);
        Button buttonPunto = findViewById(R.id.Punto);

        button0.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        buttonsuma.setOnClickListener(this);
        buttonresta.setOnClickListener(this);
        buttonmulti.setOnClickListener(this);
        buttondiv.setOnClickListener(this);
        buttonPot.setOnClickListener(this);
        buttonRaiz.setOnClickListener(this);
        buttonsen.setOnClickListener(this);
        buttoncos.setOnClickListener(this);
        buttontan.setOnClickListener(this);
        buttonBorrar.setOnClickListener(this);
        buttonClear.setOnClickListener(this);
        buttonIgual.setOnClickListener(this);
        buttonMenos.setOnClickListener(this);
        buttonPunto.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        TextView textito = findViewById(R.id.texto);
        TextView textito2 = findViewById(R.id.texto2);
        switch (v.getId()){
            case R.id.cero:
                ayuda = textito.getText().toString() + "0";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.uno:
                ayuda = textito.getText().toString() + "1";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.dos:
                ayuda = textito.getText().toString() + "2";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.tres:
                ayuda = textito.getText().toString() + "3";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.cuatro:
                ayuda = textito.getText().toString() + "4";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.cinco:
                ayuda = textito.getText().toString() + "5";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.seis:
                ayuda = textito.getText().toString() + "6";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.siete:
                ayuda = textito.getText().toString() + "7";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.ocho:
                ayuda = textito.getText().toString() + "8";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.nueve:
                ayuda = textito.getText().toString() + "9";
                textito.setText(ayuda);
                if(ayudita != 2)
                    ayudita = 1;
                break;
            case R.id.suma:
                if(ayudita == 1 && textito.getText() != null){
                    ayuda = textito.getText().toString();
                    ayudita2 = Double.parseDouble(ayuda);
                    ayuda = ayuda + " + ";
                    textito.setText("");
                    textito2.setText(ayuda);
                    ayudita = 2;
                    ayuda3 = "+";
                    ayudita4 = 0;
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.resta:
                if(ayudita == 1 && textito.getText() != null){
                    ayuda = textito.getText().toString();
                    ayudita2 = Double.parseDouble(ayuda);
                    ayuda = ayuda + " - ";
                    textito.setText("");
                    textito2.setText(ayuda);
                    ayudita = 2;
                    ayudita3 = 0;
                    ayuda3 = "-";
                    ayudita4 = 0;
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.multiplicacion:
                if(ayudita == 1 && textito.getText() != null){
                    ayuda = textito.getText().toString();
                    ayudita2 = Double.parseDouble(ayuda);
                    ayuda = ayuda + " x ";
                    textito.setText("");
                    textito2.setText(ayuda);
                    ayudita = 2;
                    ayuda3 = "x";
                    ayudita4 = 0;
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.division:
                if(ayudita == 1 && textito.getText() != null){
                    ayuda = textito.getText().toString();
                    ayudita2 = Double.parseDouble(ayuda);
                    ayuda = ayuda + " / ";
                    textito.setText("");
                    textito2.setText(ayuda);
                    ayudita = 2;
                    ayuda3 = "/";
                    ayudita4 = 0;
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.potencia:
                if(ayudita == 1){
                    ayuda = textito.getText().toString();
                    ayudita2 = Integer.parseInt(ayuda);
                    ayuda = ayuda + " ^ ";
                    textito.setText("");
                    textito2.setText(ayuda);
                    ayudita = 2;
                    ayuda3 = "^";
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.raiz:
                if(ayudita == 1){
                    ayudita2 = Integer.parseInt(textito.getText().toString());
                    help1 = ayudita2;
                    help2 = Math.sqrt(help1);
                    ayuda = Double.toString(help2);
                    Toast.makeText(this, ayuda, Toast.LENGTH_SHORT).show();
                    ayudita = 0;
                    textito.setText("");
                    textito2.setText("√" + ayudita2 + " = " + ayuda);
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.sen:
                if(ayudita == 1){
                    ayudita2 = Integer.parseInt(textito.getText().toString());
                    help1 = ayudita2;
                    help2 = Math.toRadians(help1);
                    help2 = Math.sin(help2);
                    ayuda = Double.toString(help2);
                    Toast.makeText(this, ayuda, Toast.LENGTH_SHORT).show();
                    ayudita = 0;
                    textito.setText("");
                    textito2.setText("sin(" + help1 + ") = " + ayuda);
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.cos:
                if(ayudita == 1){
                    ayudita2 = Integer.parseInt(textito.getText().toString());
                    help1 = ayudita2;
                    help2 = Math.toRadians(help1);
                    help2 = Math.cos(help2);
                    ayuda = Double.toString(help2);
                    Toast.makeText(this, ayuda, Toast.LENGTH_SHORT).show();
                    ayudita = 0;
                    textito.setText("");
                    textito2.setText("cos(" + help1 + ") = " + ayuda);
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tan:
                if(ayudita == 1 && Integer.parseInt(textito.getText().toString()) != 90){
                    ayudita2 = Integer.parseInt(textito.getText().toString());
                    help1 = ayudita2;
                    help2 = Math.toRadians(help1);
                    help2 = Math.tan(help2);
                    ayuda = Double.toString(help2);
                    Toast.makeText(this, ayuda, Toast.LENGTH_SHORT).show();
                    ayudita = 0;
                    textito.setText("");
                    textito2.setText("tan" + help1 + ") = " + ayuda);
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.borrar:
                if(ayudita == 1) {
                    ayudita3 = (textito.getText().length()) - 1;
                    if(ayudita3 != -1) {
                        ayuda2 = ayuda.substring(ayudita3, ayudita3 + 1);
                        if (ayuda2.equals(".")) {
                            ayuda = textito.getText().toString();
                            ayuda = ayuda.substring(0, ayudita3);
                            ayudita3 = 0;
                            textito.setText(ayuda);
                            ayudita4 = 0;
                        } else {
                            ayuda = textito.getText().toString();
                            ayuda = ayuda.substring(0, ayudita3);
                            ayudita3 = 0;
                            textito.setText(ayuda);
                        }
                    }
                }
                break;
            case R.id.igual:
                if(ayudita == 2) {
                    ayuda = textito.getText().toString();
                    ayudita5 = Double.parseDouble(ayuda);
                    double result;
                    switch (ayuda3) {
                        case "+":
                            result = ayudita2 + ayudita5;
                            Toast.makeText(this, Double.toString(result), Toast.LENGTH_SHORT).show();
                            textito2.setText(ayudita2 + " " + ayuda3 + " " + ayudita5 + " = " + result);
                            ayudita = 0;
                            ayudita2 = 0;
                            ayudita4 = 0;
                            ayuda = "";
                            ayuda2 = "";
                            ayuda3 = "";
                            textito.setText("");
                            break;
                        case "-":
                            result = ayudita2 - ayudita5;
                            Toast.makeText(this, Double.toString(result), Toast.LENGTH_SHORT).show();
                            textito2.setText(ayudita2 + " " + ayuda3 + " " + ayudita5 + " = " + result);
                            ayudita = 0;
                            ayudita2 = 0;
                            ayudita4 = 0;
                            ayuda = "";
                            ayuda2 = "";
                            ayuda3 = "";
                            textito.setText("");
                            break;
                        case "x":
                            result = ayudita2 * ayudita5;
                            Toast.makeText(this, Double.toString(result), Toast.LENGTH_SHORT).show();
                            textito2.setText(ayudita2 + " " + ayuda3 + " " + ayudita5 + " = " + result);
                            ayudita = 0;
                            ayudita2 = 0;
                            ayudita4 = 0;
                            ayuda = "";
                            ayuda2 = "";
                            ayuda3 = "";
                            textito.setText("");
                            break;
                        case "/":
                            result = ayudita2 / ayudita5;
                            Toast.makeText(this, Double.toString(result), Toast.LENGTH_SHORT).show();
                            textito2.setText(ayudita2 + " " + ayuda3 + " " + ayudita5 + " = " + result);
                            ayudita = 0;
                            ayudita2 = 0;
                            ayudita4 = 0;
                            ayuda = "";
                            ayuda2 = "";
                            ayuda3 = "";
                            break;
                        case "^":
                            ayuda = Integer.toString(ayudita);
                            ayuda3 = Double.toString(ayudita2);
                            help1 = ayudita2;
                            help2 = Math.pow(help1, ayudita);
                            ayuda2 = Double.toString(help2);
                            Toast.makeText(this, ayuda2, Toast.LENGTH_SHORT).show();
                            ayudita = 0;
                            textito.setText("");
                            textito2.setText(ayuda3 + "^ " + ayuda + " = " + ayuda2);
                            ayudita4 = 0;
                            break;
                    }
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.clear:
                ayudita = 0;
                textito.setText("");
                textito2.setText("");
                ayudita4 = 0;
                ayudita2 = 0;
                ayudita3 = 0;
                break;
            case R.id.menos:
                if(ayudita3 != 0){
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }else{
                    ayuda = textito.getText().toString();
                    ayuda = "-" + ayuda;
                    textito.setText(ayuda);
                    ayudita3 = 1;
                }
                break;
            case R.id.Punto:
                if(ayudita4 == 0){
                    ayuda = textito.getText().toString();
                    ayuda = ayuda + ".";
                    textito.setText(ayuda);
                    ayudita4 = 1;
                }else{
                    Toast.makeText(this, "Operacion Incorrecta", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}
